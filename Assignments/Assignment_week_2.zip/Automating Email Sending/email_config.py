email_address_config="albertandemsj@gmail.com"
pwd_config="yojgfcdatjawnihi"
server_config="smtp.gmail.com"
server_port_config=587
